"""Module for BST
CPE202

Contains the data definition of BST,
and functions (not class member methods) on BST.

Functions defined here need to be recusrive functions,
and will be used by other classes such as TreeMap as
helper functions.


Author:
    Section:
    Your Name Here
"""
class BSTNode:
    def __init__(self):
        pass

    #---- to do ----
    # implement __eq__ and __repr__
    #---------------

#---- to do ----
# implement the following recursive funstions
# write a docstring for each function
#
def get():
    pass

def contains():
    pass

def insert():
    pass

def delete():
    pass

def find_min():
    pass

def find_max():
    pass

def inorder_list():
    pass

def preorder_list():
    pass

def tree_height():
    pass

def range_search():
    pass

